# RentFlow

A premium real estate rental platform website built with React + Vite + TypeScript.

## Requirements

- Node.js 18 or higher
- npm, pnpm, or yarn

## Getting Started

```bash
# Install dependencies
npm install

# Start the dev server (opens at http://localhost:3000)
npm run dev
```

## Other commands

```bash
# Type check
npm run typecheck

# Build for production
npm run build

# Preview production build
npm run preview
```

## Pages

| Route | Page |
|---|---|
| `/` | Home |
| `/overview` | About Us |
| `/gallery` | Photo Gallery (filterable) |
| `/features` | Property Listings |
| `/realtor` | Our Agents |
| `/login` | Sign In |
| `/signup` | Create Account |
| `/forgot-password` | Reset Password |
| `/help` | Help Center |
| `/privacy` | Privacy Policy |
| `/terms` | Terms of Service |
| `/finance` | Finance / Mortgage Calculator |
| `/sell` | Sell a Home |
| `/rent` | Rent a Home |
| `/testimonials` | Client Stories |
| `/careers` | Join RentFlow |

## Stack

- React 19 + TypeScript
- Vite (dev server & bundler)
- Tailwind CSS v4
- shadcn/ui components
- wouter (routing)
- framer-motion (animations)
- lucide-react (icons)
